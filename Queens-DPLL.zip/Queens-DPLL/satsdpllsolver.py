"""
Created on 2020年10月19日19:50:28

@author: 郑逢宝，计算机11801,1804240131

Functions:
    (1) N Queens for DPLL;
"""

import os
from myarray2d import Array2D
import copy
import time
import datetime
import sys
from multiprocessing.dummy import Pool as ThreadPool
import gc

size = 7
line_counter = 0
filein = 'queens{}.in'.format(size)
fileout = 'queens{}.out'.format(size)
RESULT = []


def GetInputFile():
    global line_counter, size, filein, fileout

    template = Array2D(size, size)
    for row in range(size):
        for col in range(size):
            template[row, col] = row * size + col + 1

    constraints = ''

    # row constraints
    for row in range(size):
        for col in range(size):
            constraints += str(template[row, col]) + ' '
        constraints += '0\n'
        line_counter += 1
        for col1 in range(size):
            for col2 in range(col1 + 1, size):
                constraints += '-' + \
                    str(template[row, col1]) + ' -' + \
                    str(template[row, col2]) + ' 0\n'
                line_counter += 1

    # column constraints
    for col in range(size):
        for row in range(size):
            constraints += str(template[row, col]) + ' '
        constraints += '0\n'
        line_counter += 1
        for row1 in range(size):
            for row2 in range(row1 + 1, size):
                constraints += '-' + \
                    str(template[row1, col]) + ' -' + \
                    str(template[row2, col]) + ' 0\n'
                line_counter += 1

    # main diagonal constraints
    # upper triangle
    for col in range(size - 2, -1, -1):  
        for row1 in range(size - col):
            for row2 in range(row1 + 1, size - col):
                constraints += '-' + \
                    str(template[row1, col + row1]) + ' -' + \
                    str(template[row2, col + row2]) + ' 0\n'
                line_counter += 1
    # lower triangle
    for row in range(size - 2, 0, -1):  
        for col1 in range(size - row):
            for col2 in range(col1 + 1, size - row):
                constraints += '-' + \
                    str(template[row + col1, col1]) + ' -' + \
                    str(template[row + col2, col2]) + ' 0\n'
                line_counter += 1

    # secondary diagonal constraints
    # lower triangle
    for col in range(size - 2, -1, -1):  
        for row1 in range(size - 1, col - 1, -1):
            for row2 in range(row1 - 1, col - 1, -1):
                constraints += '-' + str(template[row1, col + size - 1 - row1]) + ' -' + str(
                    template[row2, col + size - 1 - row2]) + ' 0\n'
                line_counter += 1
    # upper triangle
    for row in range(1, size - 1): 
        for col1 in range(row + 1):
            for col2 in range(col1 + 1, row + 1):
                constraints += '-' + \
                    str(template[row - col1, col1]) + ' -' + \
                    str(template[row - col2, col2]) + ' 0\n'
                line_counter += 1

    with open(filein, 'w') as f:
        f.write(constraints)


def HavePureP(S):    #
    for items in S:
        if len(items) == 1:
            return True, items[0]
    return False, 0


def BothIn(S, p):   #
    listp = []
    list_p = []
    listp.append(p)
    list_p.append(-p)
    if S.count(listp) > 0 and S.count(list_p) > 0:
        return True
    return False


def GetShortestClause(S):
    min_clause_p = S[0][0]
    min_clause_size = sys.maxsize
    for items in S:
        if min_clause_size > len(items):
            min_clause_size = len(items)
    min_clause_p = items[0]  # get the first variable
    return min_clause_p


def IsEmpty(S):
    if len(S) == 0:
        return True
    else:
        return False


def ClearOnlyNullList(S):
    S = [x for x in S if x]


def Simplify(S, p):
    listp = []
    listp.append(p)
    for index in range(len(S)-1, -1, -1):  # reversr visit
        set_item = set(S[index])
        if p in set_item:
            S.remove(S[index])
        elif -p in set_item:
            S[index].remove(-p)
    return copy.deepcopy(S)


# @profile
def DPLL(S):
    gc.disable()
    global RESULT
    if IsEmpty(S):
        return ("satisfiable")
    havePureP, p = HavePureP(S)
    while(havePureP):
        if BothIn(S, p):
            return ("unsatisfiable")
        else:
            RESULT.append(p)
            S = Simplify(S, p)
        havePureP, p = HavePureP(S)
    if IsEmpty(S):
        return ("satisfiable")
    q = GetShortestClause(S)
    gc.disable()
    S_copy = copy.deepcopy(S)
    gc.enable()
    index_ = len(RESULT)
    RESULT.append(q)
    if DPLL(Simplify(S_copy, q)) == "satisfiable":
        return ("satisfiable")
    else:
        gc.disable()
        S_copy1 = copy.deepcopy(S)
        gc.enable()
        del RESULT[index_:]
        RESULT.append(-q)
        return (DPLL(Simplify(S_copy1, -q)))


# @profile
def main():
    global RESULT
    allresults = []
    solution_counter = 0
    #GetInputFile() #get the constraints to file
    S_num = []
    fin = open(filein)
    S = fin.readlines()
    fin.close()
    for items in S:
        gc.disable()
        item = []
        for it in items.split():
            if(it != '0' or it == ''):
                item.append(int(it))
        S_num.append(copy.deepcopy(item))
        gc.enable()
    while True:
        if DPLL(S_num) == "unsatisfiable":
            break
        solution_counter += 1
        _result = []
        gc.disable()
        for i in range(len(RESULT)):
            _result.append(-RESULT[i])
        allresults.append(copy.deepcopy(RESULT))
        S_num.append(copy.deepcopy(_result))
        gc.enable()
        RESULT = []
        print('find solution:%d' % (solution_counter))
    print('num_solution:%d' % (solution_counter))

    with open(fileout, 'w') as f:
        f.write(str(solution_counter) + '\n')
        str_res = ''
        for items in allresults:
            for item in items:
                str_res += str(item)+' '
            str_res += '0\n'
        f.write(str_res)


if __name__ == "__main__":
    # cProfile.run('main()')
    main()
