# -*- coding: utf-8 -*-
"""
Created on Thu Aug 20 21:23:15 2020

@author: duxiaoqin
Functions:
    (1)Draw the result of satsolver.py
"""

from time import *
from graphics import *
from board import *
from boarddraw import *

def DrawSATResult(size, filein, queenimg1, queenimg2):
    win = GraphWin('SATSolver Results', 600, 600, autoflush = False)
    board = Board(size)

    with open(filein) as f:
        allines = f.readlines()
        
    Solutions = []
    for line in allines[1:]:
        queens = line.split()
        Solution = []
        for queen in queens:
            queen = int(queen) - 1
            if queen >= 0:
                Solution.append((queen // size, queen % size))
        Solutions.append(Solution)
    
    boarddraw = BoardDraw(win, board, queenimg1, queenimg2)

    text = Text(Point(board.width/2+1, 0.5), '')
    text.setTextColor('red')
    text.draw(win)

    for index, Solution in enumerate(Solutions):
        text.setText('{} Queens: {}/{} Solutions'.format(size, index+1, len(Solutions)))
        board.board.clear(Board.EMPTY)
        for Xi, vi in Solution:
            board[Xi, vi] = Board.OCCUPIED
        boarddraw.draw(board)
        time.sleep(0.25)
        if win.checkKey() == 'Escape':
            win.close()
            exit()
    time.sleep(1.0)
    win.close()
    
def main():
#    DrawSATResult(4, 'queens4.out', 'Queen4-1.png', 'Queen4-2.png')
#    DrawSATResult(5, 'queens5.out', 'Queen8-1.png', 'Queen8-2.png')
#    DrawSATResult(6, 'queens6.out', 'Queen8-1.png', 'Queen8-2.png')
#    DrawSATResult(7, 'queens7.out', 'Queen8-1.png', 'Queen8-2.png')
    DrawSATResult(8, 'queens8.out', 'Queen8-1.png', 'Queen8-2.png')
#    DrawSATResult(9, 'queens9.out', 'Queen16-1.png', 'Queen16-2.png')
#    DrawSATResult(10, 'queens10.out', 'Queen16-1.png', 'Queen16-2.png')
#    DrawSATResult(11, 'queens11.out', 'Queen16-1.png', 'Queen16-2.png')
    
if __name__ == '__main__':
    main()