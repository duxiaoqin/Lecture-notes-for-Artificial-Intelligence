/*
	Programmed by Xiaoqin Du, 383979583@qq.com
	School of Math and Computer Science, 
	Wuhan Textile University
*/

#include "stdafx.h"

#include "MyBase.h"

std::ifstream& MyObjects::operator>>(std::ifstream& in, MyObjects::TicTacToeStone& stone)
{
	in.read((char*)&stone.row, sizeof(stone.row));
	in.read((char*)&stone.col, sizeof(stone.col));
	in.read((char*)&stone.magic_code, sizeof(stone.magic_code));

	return in;
}

std::ofstream& MyObjects::operator<<(std::ofstream& out, MyObjects::TicTacToeStone& stone)
{
	out.write((char*)&stone.row, sizeof(stone.row));
	out.write((char*)&stone.col, sizeof(stone.col));
	out.write((char*)&stone.magic_code, sizeof(stone.magic_code));

	return out;
}

std::ifstream& MyObjects::operator>>(std::ifstream& in, std::deque<MyObjects::TicTacToeStone*>*& pDeqStone)
{
	size_t size;
	in.read((char*)&size, sizeof(size));

	pDeqStone = new std::deque<MyObjects::TicTacToeStone*>();

	for (unsigned int i = 0; i < size; i++) {
		MyObjects::TicTacToeStone* pStone = new MyObjects::TicTacToeStone();
		in >> *pStone;
		pDeqStone->push_back(pStone);
	}

	return in;
}

std::ofstream& MyObjects::operator<<(std::ofstream& out, std::deque<MyObjects::TicTacToeStone*>* pDeqStone)
{
	std::deque<MyObjects::TicTacToeStone*>::iterator stone_iter;

	size_t size;
	size = pDeqStone->size();
	out.write((char*)&size, sizeof(size));

	for (stone_iter = pDeqStone->begin(); stone_iter != pDeqStone->end(); stone_iter++) {
		out << **stone_iter;
	}

	return out;
}