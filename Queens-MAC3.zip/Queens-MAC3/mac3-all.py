'''
Created on sun 2020/11/6 21:00

@author: zhoudi, 周迪, 研2014, 2015363060

Functions:
    (1)MAC-3 Algorithm for all solution;
'''

from graphics import *
from board import *
from boarddraw import *
import copy
import time
from queue import Queue

solutions=[]

class viInfo:
    def __init__(self, v):
        self.value = v
        self.flag = Board.UNMARK
        self.level = -1


def DomainWipedOut(Vi):
    for vi in Vi:
        if vi.flag == Board.UNMARK:
            return False
    return True


def RestoreDomainAtLevel(level):
    for Xi, Vi in Vars:
        for vi in Vi:
            if vi.flag == Board.MARK and vi.level == level:
                vi.flag = Board.UNMARK
                vi.level = -1

def Revise(Xi,Xj,level):
    Delete = False
    for vi in Vars[Xi][1]:
        if vi.flag == Board.MARK:
            continue
        Found = False
        for vj in Vars[Xj][1]:
            if (vj.flag == Board.UNMARK and vi.value != vj.value and abs(Xi - Xj) != abs(vi.value - vj.value)):
                Found = True
                break
        if not Found:
            vi.flag = Board.MARK
            vi.level = level
            Delete = True
    return Delete

def MaintainingArcConsistency(level,end):
    while not Arcs.empty():
        t = Arcs.get()
        Xi = t[0]
        Xj = t[1]
        if Revise(Xi,Xj,level):
            if DomainWipedOut(Vars[Xi][1]):
                Arcs.queue.clear()
                return False
            else:
                for Xk in range(level+1,end):
                    if Xk==Xi:
                        continue
                    Arcs.put((Xk,Xi))
    return True


def BacktrackingWithMAC(level,end,Solution):
    Xi, Vi = Vars[level]
    for vi in Vi:
        if vi.flag == Board.UNMARK:
            Solution.append((Xi, vi))
            if level == end-1:
                # print(Solution)
                solutions.append(copy.deepcopy(Solution))
                Solution.pop()
                return True
            else:
                for v_i in Vi:
                    if v_i == vi:
                        continue
                    if v_i.flag == Board.UNMARK:
                        v_i.flag = Board.MARK
                        v_i.level = level
                for Xj in range(level+1,end):
                    Arcs.put((Xj,Xi))
                if MaintainingArcConsistency(level,end):
                    BacktrackingWithMAC(level + 1,end, Solution)
            Solution.pop()
            RestoreDomainAtLevel(level)
    return False


Arcs = Queue()
Vars = []

def main():
    win = GraphWin('Backtracking with MAC-3 for Queen', 600, 600, autoflush=False)
    #这里修改皇后的个数
    num = 8
    board = Board(num)

    # Vi = [viInfo(0), viInfo(1), viInfo(2), viInfo(3), viInfo(4), viInfo(5), viInfo(6), viInfo(7),viInfo(8), viInfo(9), viInfo(10), viInfo(11), viInfo(12), viInfo(13), viInfo(14), viInfo(15)]

    # Vi = [viInfo(0), viInfo(1), viInfo(2), viInfo(3), viInfo(4), viInfo(5), viInfo(6), viInfo(7)]
    Vi = [viInfo(i) for i in range(num)]

    # Vi = [viInfo(0), viInfo(1), viInfo(2), viInfo(3)]
    for row in range(board.height):
        Vars.append((row, copy.deepcopy(Vi)))
    text = Text(Point(board.width/2+1, 0.5), 'Searching...')
    text.setTextColor('red')
    text.draw(win)

    boarddraw = BoardDraw(win, board, 'Queen8-1.png', 'Queen8-2.png')
    boarddraw.draw(board)
    Solution = []

    for i in range(board.height):
        for j in range(board.height):
            if i==j:
                continue
            Arcs.put((i,j))
    if MaintainingArcConsistency(0,board.height):
        BacktrackingWithMAC(0,board.height,Solution)




    # print(len(solutions))

    while True:
        for index, solution in enumerate(solutions):
            text.setText('{}/{} Solutions'.format(index + 1, len(solutions)))
            for Xi, vi in solution:
                board[Xi, vi.value] = Board.OCCUPIED
            boarddraw.draw(board)
            board.board.clear(Board.EMPTY)
            time.sleep(0.2)
            if win.checkKey() == 'Escape':
                win.close()
                exit()

    win.close()



if __name__ == "__main__":
    main()
