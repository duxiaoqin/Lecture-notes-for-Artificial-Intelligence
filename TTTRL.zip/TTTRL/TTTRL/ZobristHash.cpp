/*
	Programmed by Xiaoqin Du, 383979583@qq.com
	School of Math and Computer Science, 
	Wuhan Textile University
*/

#include "stdafx.h"

#include "Board.h"
#include "ZobristHash.h"

MyObjects::ZobristHash::ZobristHash(int nWidth, int nHeight)
{
	m_nWidth = nWidth;
	m_nHeight = nHeight;

	m_nDepth = 361; //19*19

	//ȫ�ڷ�����״̬�����ʼ��
	m_ppBlack = new int*[m_nHeight];
	for (int row = 0; row < m_nHeight; row++) {
		m_ppBlack[row] = new int[m_nWidth];
	}	

	//ȫ�׷�����״̬�����ʼ��
	m_ppWhite = new int*[m_nHeight];
	for (int row = 0; row < m_nHeight; row++) {
		m_ppWhite[row] = new int[m_nWidth];
	}	

	//ȫ�հ�����״̬�����ʼ��
	m_ppEmpty = new int*[m_nHeight];
	for (int row = 0; row < m_nHeight; row++) {
		m_ppEmpty[row] = new int[m_nWidth];
	}

	//��������ʼ��
	m_pDepth = new int[m_nDepth];

	std::ifstream in(L"..\\zobrist.dat", std::ifstream::binary);
	if (in) {//��������л�
		for (int row = 0; row < m_nHeight; row++) {
			for (int col = 0; col < m_nWidth; col++) {
				in.read((char*)&m_ppBlack[row][col], sizeof(m_ppBlack[row][col]));
				in.read((char*)&m_ppWhite[row][col], sizeof(m_ppWhite[row][col]));
				in.read((char*)&m_ppEmpty[row][col], sizeof(m_ppEmpty[row][col]));
			}
		}
		for (int index = 0; index < m_nDepth; index++) {
			in.read((char*)&m_pDepth[index], sizeof(m_pDepth[index]));
		}
	} else {//����д���л�
		std::ofstream out(L"..\\zobrist.dat", std::ofstream::binary);

		//��ʼΪ��״̬��������������
		srand((unsigned)time(NULL)); //�������������
		for (int row = 0; row < m_nHeight; row++) {
			for (int col = 0; col < m_nWidth; col++) {
				m_ppBlack[row][col] = rand() % MAX_VALUE;
				m_ppWhite[row][col] = rand() % MAX_VALUE;
				m_ppEmpty[row][col] = rand() % MAX_VALUE;

				//д���л�
				out.write((char*)&m_ppBlack[row][col], sizeof(m_ppBlack[row][col]));
				out.write((char*)&m_ppWhite[row][col], sizeof(m_ppWhite[row][col]));
				out.write((char*)&m_ppEmpty[row][col], sizeof(m_ppEmpty[row][col]));
			}
		}

		//������������
		for (int index = 0; index < m_nDepth; index++) {
			m_pDepth[index] = rand() % MAX_VALUE;
			out.write((char*)&m_pDepth[index], sizeof(m_pDepth[index]));
		}
	}
}

MyObjects::ZobristHash::~ZobristHash()
{
	delete[] m_pDepth;

	for (int row = 0; row < m_nHeight; row++) {
		delete[] m_ppBlack[row];
	}
	delete[] m_ppBlack;

	for (int row = 0; row < m_nHeight; row++) {
		delete[] m_ppWhite[row];
	}
	delete[] m_ppWhite;

	for (int row = 0; row < m_nHeight; row++) {
		delete[] m_ppEmpty[row];
	}
	delete[] m_ppEmpty;
}

//nWidth��nHeight�����̵�ʵ�ʿ��Ⱥ͸߶�
int MyObjects::ZobristHash::GenerateHashValue(short** ppGrid, int nWidth, int nHeight, int nDepth)
{
	int hash = 0;

	for (int row = 0; row < nHeight; row++) {
		for (int col = 0; col < nWidth; col++) {
			if (ppGrid[row][col] == MyObjects::Board::BLACKFLAG)
				hash = hash ^ m_ppBlack[row][col];
			else if (ppGrid[row][col] == MyObjects::Board::WHITEFLAG)
				hash = hash ^ m_ppWhite[row][col];
			else
				hash = hash ^ m_ppEmpty[row][col];
		}
	}

	return hash ^ m_pDepth[nDepth];
}

//��һ�ּ������HASHֵ�ķ�����ֻ�������ӱ仯�������ô��ɿհ�->�ڻ���ӣ�
int MyObjects::ZobristHash::GenerateHashValue(int hash, int row, int col, short flag, int nOldDepth, int nDepth)
{
	if (flag == MyObjects::Board::BLACKFLAG)
		hash = hash ^ m_ppEmpty[row][col] ^ m_ppBlack[row][col];
	else if (flag == MyObjects::Board::WHITEFLAG)
		hash = hash ^ m_ppEmpty[row][col] ^ m_ppWhite[row][col];

	return hash ^ m_pDepth[nOldDepth] ^ m_pDepth[nDepth];
}

//��һ�ּ������HASHֵ�ķ�����ֻ�������ӱ仯�������ô��ɿհ�->�ڻ���ӣ�
int MyObjects::ZobristHash::GenerateHashValue(int hash, int row, int col, bool flag, int nOldDepth, int nDepth)
{
	if (flag)
		hash = hash ^ m_ppEmpty[row][col] ^ m_ppBlack[row][col];
	else
		hash = hash ^ m_ppEmpty[row][col] ^ m_ppWhite[row][col];

	return hash ^ m_pDepth[nOldDepth] ^ m_pDepth[nDepth];
}

int MyObjects::ZobristHash::GenerateHashValue(std::deque<MyObjects::TicTacToeStone*>* pXStones, std::deque<MyObjects::TicTacToeStone*>* pOStones, std::deque<MyObjects::TicTacToeStone*>* pNStones, int nDepth)
{
	int hash = 0;

	std::deque<MyObjects::TicTacToeStone*>::iterator iter;

	for (iter = pXStones->begin(); iter < pXStones->end(); iter++) {
		hash = hash ^ m_ppBlack[(*iter)->row][(*iter)->col];
	}

	for (iter = pOStones->begin(); iter < pOStones->end(); iter++) {
		hash = hash ^ m_ppWhite[(*iter)->row][(*iter)->col];
	}

	for (iter = pNStones->begin(); iter < pNStones->end(); iter++) {
		hash = hash ^ m_ppEmpty[(*iter)->row][(*iter)->col];
	}

	return hash ^ m_pDepth[nDepth];
}