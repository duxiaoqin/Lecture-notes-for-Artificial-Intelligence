# -*- coding: utf-8 -*-
"""
Created on Tue Sep 18 10:19:34 2018

@author: duxiaoqin
"""

from random import *
from graphics import *

def isPointInRect(point, rect):
    x = point[0]
    y = point[1]
    lx = rect[0]
    ly = rect[1]
    rx = rect[2]
    ry = rect[3]
    if lx <= x <= rx and ly <= y <= ry:
        return 0
    elif (x <= lx or x >= rx) and (y <= ly or y >= ry):
        return 1
    elif x <= lx or x >= rx:
        return 2
    elif y <= ly or y >= ry:
        return 3

def updateCircle(win, circle, delta, style='random'):
    circle.undraw()
    circle.move(delta[0], delta[1])
    leftdown = circle.getP1()
    rightup = circle.getP2()
    point1 = [leftdown.getX(), leftdown.getY()]
    point2 = [rightup.getX(), rightup.getY()]
    rect = [0.0, 0.0, 10.0, 10.0]
    if isPointInRect(point1, rect) == 1 or isPointInRect(point2, rect)== 1:
        circle.move(-delta[0], -delta[1])
        delta[0], delta[1] = -delta[0], -delta[1]
    elif isPointInRect(point1, rect) == 2 or isPointInRect(point2, rect) == 2:
        circle.move(-delta[0], -delta[1])
        delta[0], delta[1] = -delta[0], delta[1]
    elif isPointInRect(point1, rect) == 3 or isPointInRect(point2, rect)== 3:
        circle.move(-delta[0], -delta[1])
        delta[0], delta[1] = delta[0], -delta[1]
    else:
        if style == 'random':
            delta[0], delta[1] = delta[0]+random()*0.001, delta[1]+random()*0.001

    circle.move(delta[0], delta[1])
    circle.draw(win)

def main():
    seed()
    
    win = GraphWin('Moving Circle', 600, 600, autoflush=False)
    win.setBackground('gray')
    win.setCoords(0.0, 0.0, 10.0, 10.0)
    
    circle = Circle(Point(5.0, 5.0), 0.5)
    circle.setOutline('red')
    circle.setFill('blue')
    delta = [0.03+random()*0.01, 0.01+random()*0.01]
    style = 'normal'
    while True:
        key = win.checkKey()
        if key == 'Escape':
            break
        if key == 'Left':
            style = 'normal'
        elif key == 'Right':
            style = 'random'
        updateCircle(win, circle, delta, style)
        print(style)
        update(30)
        
    win.close()
    
if __name__ == '__main__':
    main()