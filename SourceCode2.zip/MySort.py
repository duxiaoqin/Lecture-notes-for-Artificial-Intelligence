def main():
    records = {}
    with open('data.txt', 'r') as f:
        for line in f:
            record = line.split()
            name = record[0]
            scores = [float(item) for item in record[1:]]
            records[name] = scores
    
    for name, scores in records.items():
        print(name, scores)
        
    print('*'*36)
        
    results = sorted(records.items())

    for name, scores in results:
        print(name, scores)

    print('*'*36)
        
    results = sorted(records.items(), key = lambda item:item[1][0])

    for name, scores in results:
        print(name, scores)
        
if __name__ == '__main__':
    main()