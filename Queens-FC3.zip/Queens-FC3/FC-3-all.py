'''
Created on sun 2020/10/6 19:44

@author: zhengfengbao, 郑逢宝, 计算机11801, 1804240131
@Functions:
    (1)FC-3 Algorithm for all solutions;

'''

from graphics import *
from board import *
from boarddraw import *
import copy
import time


class viInfo:
    def __init__(self, v):
        self.value = v
        self.flag = Board.UNMARK
        self.level = 0


def DomainWipedOut(Xi, Vi):
    for vi in Vi:
        if vi.flag == Board.UNMARK:
            return False
    return True


def RestoreDomainAtLevel(Vars, level):
    for Xi, Vi in Vars:
        for vi in Vi:
            if vi.flag == Board.MARK and vi.level == level:
                vi.flag = Board.UNMARK


def ForwardChecking(Vars, level, Xi, vi):
    for Xj, Vj in Vars:
        for vj in Vj:
            if (Xi == Xj or vi.value == vj.value or abs(Xi-Xj) == abs(vi.value-vj.value)):
                if vj.flag == Board.UNMARK:
                    vj.flag = Board.MARK
                    vj.level = level
        if DomainWipedOut(Xj, Vj):
            return False
    return True


def BacktrackingWithForwardChecking(Vars, level, Solution, Solutions):
    Xi, Vi = Vars[0]
    for vi in Vi:
        if vi.flag == Board.UNMARK:
            Solution.append((Xi, vi))
            if len(Vars) == 1:
                Solutions.append(copy.deepcopy(Solution))
            else:
                Vars_C = copy.deepcopy(Vars)
                Vars_C.pop(0)
                ForwardChecking(Vars_C, level, Xi, vi)
                BacktrackingWithForwardChecking(
                    Vars_C, level+1, Solution, Solutions)
                RestoreDomainAtLevel(Vars_C, level)
            Solution.pop()

    return False


def main():
    win = GraphWin('Backtracking for Queen', 600, 600, autoflush=False)
    board = Board(8)
    boarddraw = BoardDraw(win, board, 'Queen8-1.png', 'Queen8-2.png')

    Vars = []
    Vi = [viInfo(0), viInfo(1), viInfo(2), viInfo(
        3), viInfo(4), viInfo(5), viInfo(6), viInfo(7)]
    for row in range(board.height):
        Vars.append((row, copy.deepcopy(Vi)))

    Solution = []
    Solutions = []

    text = Text(Point(board.width/2+1, 0.5), 'Searching...')
    text.setTextColor('red')
    text.draw(win)
    boarddraw.draw(board)
    BacktrackingWithForwardChecking(Vars, 1, Solution, Solutions)

    while True:
        for index, solution in enumerate(Solutions):
            text.setText('{}/{} Solutions'.format(index+1, len(Solutions)))
            for Xi, vi in solution:
                board[Xi, vi.value] = Board.OCCUPIED
            boarddraw.draw(board)
            board.board.clear(Board.EMPTY)
            time.sleep(0.2)
            if win.checkKey() == 'Escape':
                win.close()
                exit()

    win.close()


if __name__ == "__main__":
    main()
