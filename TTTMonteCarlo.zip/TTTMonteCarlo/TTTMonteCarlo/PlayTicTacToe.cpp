/*
	Programmed by Xiaoqin Du, 383979583@qq.com
	School of Math and Computer Science, 
	Wuhan Textile University
*/

#include "stdafx.h"

#include "PlayTicTacToe.h"

MyAI::TicTacToeNode MyAI::PlayTicTacToe::m_TTTNodeResult;

//minimax��alpha-beta�㷨ʹ��
MyAI::TicTacToeNode::TicTacToeNode()
{
	stone.row = -1;
	stone.col = -1;
	stone.magic_code = -1;
	value = 0;

	depth = 0; //root node
	self = 0;

	wins = 0.0f;
	visits = 0.0f;
	player = true;

	p_child_stones = NULL;
	p_unchild_stones = NULL;
	m_pMapTTT = NULL;

	max_uct_stone.row = -1; max_uct_stone.col = -1; max_uct_stone.magic_code = -1;
	max_uct_value = 0.0f;
}

MyAI::TicTacToeNode::TicTacToeNode(int row, int col, int code, int depth, int self, std::deque<MyObjects::TicTacToeStone*>* pUntriedChild, bool player, std::unordered_map<int, std::deque<TicTacToeNode*>*>* pMapTTT)
{
	stone.row = row;
	stone.col = col;
	stone.magic_code = code;
	value = 0;

	this->depth = depth;
	this->self = self;

	wins = 0.0f;
	visits = 0.0f;
	this->player = player; //��ǰ�ڵ���BLACK��������WHITE��

	p_child_stones = new std::deque<MyObjects::TicTacToeStone*>();
	p_unchild_stones = pUntriedChild;

	m_pMapTTT = pMapTTT;

	max_uct_stone.row = -1; max_uct_stone.col = -1; max_uct_stone.magic_code = -1;
	max_uct_value = 0.0f;
}

MyAI::TicTacToeNode::~TicTacToeNode()
{
	std::deque<MyObjects::TicTacToeStone*>::iterator stone_iter;

	if (p_child_stones) {
		for (stone_iter = p_child_stones->begin(); stone_iter < p_child_stones->end(); stone_iter++) {
			delete *stone_iter;
		}
		p_child_stones->clear();
		delete p_child_stones;
	}

	if (p_unchild_stones) {
		for (stone_iter = p_unchild_stones->begin(); stone_iter < p_unchild_stones->end(); stone_iter++) {
			delete *stone_iter;
		}
		p_unchild_stones->clear();
		delete p_unchild_stones;
	}
}

//���ڵ�����к��ӽڵ㶼��ͳ����Ϣʱ���ܵ��ñ�����
//���򣬽�������Ч�����ӣ�stone.row = stone.col = -1
MyObjects::TicTacToeStone MyAI::TicTacToeNode::UCTSelectChild()
{
	int child; //���ӽڵ�HASHֵ
	MyObjects::TicTacToeStone max_stone; //����������UCTֵ��������Ϣ���������ص�������Ϣ
	float uct_value;
	float max_value = -1.0f; //�������UCTֵ
	bool isValid = false; //UCTѡ���ӽڵ��Ƿ���Ч

	max_stone.row = -1; max_stone.col = -1; max_stone.magic_code = -1;

	std::deque<MyObjects::TicTacToeStone*>::iterator stone_iter; //p_unchild_stones������
	std::unordered_map<int, std::deque<TicTacToeNode*>*>::iterator hash_iter;
	std::deque<TicTacToeNode*>::iterator child_iter; //HASHֵ��ͬ�Ľڵ������

	for (stone_iter = p_unchild_stones->begin(); stone_iter < p_unchild_stones->end(); stone_iter++) {//�������еĺ��ӽڵ�����
		isValid = false;
		//���ɺ��ӽڵ��HASHֵ
		child = MyObjects::m_objZobristHash.GenerateHashValue(this->self, (*stone_iter)->row, (*stone_iter)->col, player, this->depth, this->depth + 1);
		//��HASH���в���child
		hash_iter = m_pMapTTT->find(child);
		if ( hash_iter != m_pMapTTT->end()) {//�ҵ�child
			for (child_iter = hash_iter->second->begin(); child_iter < hash_iter->second->end(); child_iter++) {
				if ((*child_iter)->stone.row == (*stone_iter)->row &&
					(*child_iter)->stone.col == (*stone_iter)->col &&
					(*child_iter)->depth == this->depth + 1) {//׼ȷ���ҵ�����HASHֵ��ͬchild�е�һ��
						uct_value = (*child_iter)->wins / (*child_iter)->visits + 
							sqrt(2.0f * log(this->visits) / (*child_iter)->visits);
						if (uct_value > max_value) {
							max_value = uct_value;
							max_stone.row = (*stone_iter)->row;
							max_stone.col = (*stone_iter)->col;
							max_stone.magic_code = (*stone_iter)->magic_code;
						}
						isValid = true;
						break;
				}
			}
		}
		if (!isValid) //������Ч��UCTѡ���ӽڵ㣬��ֹ����
			break;
	}

	if (!isValid) {//������Ч��UCTѡ���ӽڵ�
		max_value = 0.0f;
		max_stone.row = -1; max_stone.col = -1; max_stone.magic_code = -1;
	}

	this->max_uct_stone = max_stone;
	this->max_uct_value = max_value;

	return max_stone;
}

//UCT����
MyAI::TicTacToeNode* MyAI::TicTacToeNode::UCTGetMaxChild()
{
	int child; //���ӽڵ�HASHֵ
	TicTacToeNode* max_node = NULL; //������ʴ������ĺ��ӽڵ�
	float max_visits = -1.0f; //������߷��ʴ���

	std::deque<MyObjects::TicTacToeStone*>::iterator stone_iter; //p_unchild_stones������
	std::unordered_map<int, std::deque<TicTacToeNode*>*>::iterator hash_iter;
	std::deque<TicTacToeNode*>::iterator child_iter; //HASHֵ��ͬ�Ľڵ������

	for (stone_iter = p_unchild_stones->begin(); stone_iter < p_unchild_stones->end(); stone_iter++) {//�������еĺ��ӽڵ�����
		//���ɺ��ӽڵ��HASHֵ
		child = MyObjects::m_objZobristHash.GenerateHashValue(this->self, (*stone_iter)->row, (*stone_iter)->col, player, this->depth, this->depth + 1);
		//��HASH���в���child
		hash_iter = m_pMapTTT->find(child);
		if ( hash_iter != m_pMapTTT->end()) {//�ҵ�child
			for (child_iter = hash_iter->second->begin(); child_iter < hash_iter->second->end(); child_iter++) {
				if ((*child_iter)->stone.row == (*stone_iter)->row &&
					(*child_iter)->stone.col == (*stone_iter)->col &&
					(*child_iter)->depth == this->depth + 1) {//׼ȷ���ҵ�����HASHֵ��ͬchild�е�һ��
						if ((*child_iter)->visits > max_visits) {//���ʴ�������ʤ�����
							max_visits = (*child_iter)->visits;
							max_node = *child_iter;
						}
						break;
				}
			}
		}
	}

	return max_node;
}

//�ѱ��ڵ���뵽HASH MAP��
bool MyAI::TicTacToeNode::AddToHashmap(TicTacToeNode** ppTTTNode)
{
	std::unordered_map<int, std::deque<TicTacToeNode*>*>* pMapTTT;

	std::unordered_map<int, std::deque<TicTacToeNode*>*>::iterator hash_iter;
	std::deque<TicTacToeNode*>::iterator node_iter;
	std::deque<TicTacToeNode*>* pDeqNode;
	bool isFind = false;

	pMapTTT = m_pMapTTT;

	//��HASH���в��ұ��ڵ�
	hash_iter = pMapTTT->find(this->self);
	if ( hash_iter != pMapTTT->end()) {//�ҵ���HASHֵ
		for (node_iter = hash_iter->second->begin(); node_iter < hash_iter->second->end(); node_iter++) {
			bool equFlag;
			equFlag = (*node_iter)->stone.row == stone.row &&//UCT��RL�㷨ʹ�ã������ϸ�
				        (*node_iter)->stone.col == stone.col &&
						(*node_iter)->depth == this->depth;
			if (equFlag) {//�ҵ��øýڵ�
				isFind = true;
				*ppTTTNode = *node_iter;
				break;
			}
		}
		if (!isFind) {
			hash_iter->second->push_back(this);
			*ppTTTNode = this;
		}
	}
	else {//û���ҵ���HASHֵ
		pDeqNode = new std::deque<TicTacToeNode*>();
		pDeqNode->push_back(this);
		pMapTTT->insert(std::unordered_map<int, std::deque<TicTacToeNode*>*>::value_type(this->self, pDeqNode));
		*ppTTTNode = this;
	}

	return !isFind;
}

//��������δ��ʹ��
void MyAI::TicTacToeNode::AddChildToHashmap(MyObjects::TicTacToeStone* pStone)
{
	std::unordered_map<int, std::deque<TicTacToeNode*>*>* pMapTTT;

	TicTacToeNode* pNewNode; //�½��ĺ��ӽڵ㣬����PlayTicTacToe�е�m_mapTTT�ͷ�
	std::deque<MyObjects::TicTacToeStone*>::iterator stone_iter;
	std::deque<MyObjects::TicTacToeStone*>* pDeqTTTStone; //�½��ĺ��ӽڵ��p_unchild_stones������PlayTicTacToe�е�m_mapTTT�ͷ�
	MyObjects::TicTacToeStone* pTTTStone; //�½����ӽڵ�p_unchild_stones�е����������PlayTicTacToe�е�m_mapTTT�ͷ�
	bool isFind;
	int child;
	std::unordered_map<int, std::deque<TicTacToeNode*>*>::iterator hash_iter;
	std::deque<TicTacToeNode*>* pDeqChild;
	std::deque<TicTacToeNode*>::iterator child_iter;

	pMapTTT = m_pMapTTT;

	pDeqTTTStone = new std::deque<MyObjects::TicTacToeStone*>();

	//p_unchild_stones
	for (stone_iter = p_unchild_stones->begin(); stone_iter < p_unchild_stones->end(); stone_iter++) {
		if ((*stone_iter)->row == pStone->row &&
			(*stone_iter)->col == pStone->col) //�ҵ���������
			continue;
		pTTTStone = new MyObjects::TicTacToeStone();
		pTTTStone->row = (*stone_iter)->row;
		pTTTStone->col = (*stone_iter)->col;
		pTTTStone->magic_code = (*stone_iter)->magic_code;
		pDeqTTTStone->push_back(pTTTStone);
	}

	//�½�һ���ڵ㣬����TicTacToe HASH����
	isFind = false;
	child = MyObjects::m_objZobristHash.GenerateHashValue(this->self, pStone->row, pStone->col, player, this->depth, this->depth + 1);
	pNewNode = new TicTacToeNode(pStone->row, pStone->col, pStone->magic_code, 
		this->depth + 1, this->self, pDeqTTTStone, !player, m_pMapTTT);
	//��HASH���в���child
	hash_iter = pMapTTT->find(child);
	if ( hash_iter != pMapTTT->end()) {//�ҵ���HASHֵ
		for (child_iter = hash_iter->second->begin(); child_iter < hash_iter->second->end(); child_iter++) {
			bool equFlag;
			equFlag = (*child_iter)->stone.row == pStone->row &&
						(*child_iter)->stone.col == pStone->col &&
						(*child_iter)->depth == this->depth + 1;
			if (equFlag) {//�ҵ���child
				isFind = true;
				break;
			}
		}
		if (!isFind)
			hash_iter->second->push_back(pNewNode);
	}
	else {//û���ҵ���HASHֵ
		pDeqChild = new std::deque<TicTacToeNode*>();
		pDeqChild->push_back(pNewNode);
		pMapTTT->insert(std::unordered_map<int, std::deque<TicTacToeNode*>*>::value_type(child, pDeqChild));
	}
				
	if (isFind) {//�Ѿ����ڸ�child�ڵ�
		for (stone_iter = pDeqTTTStone->begin(); stone_iter < pDeqTTTStone->end(); stone_iter++) {
			delete *stone_iter;
		}
		pDeqTTTStone->clear();
		delete pDeqTTTStone;

		delete pNewNode;
	}
}

//UCT����
void MyAI::TicTacToeNode::UCTUpdate(float result)
{
	this->visits += 1;
	this->wins += result;
}

MyAI::PlayTicTacToe::PlayTicTacToe(MyObjects::TicTacToe& ttt)
{
	m_pTTT = new MyObjects::TicTacToe(ttt);
	m_hMinimaxThread = NULL;
	m_bResult = false;
}

MyAI::PlayTicTacToe::~PlayTicTacToe()
{
	Clear();
	ClearHashMap();
}

void MyAI::PlayTicTacToe::ClearHashMap()
{
	std::unordered_map<int, std::deque<TicTacToeNode*>*>::iterator map_iter;
	std::deque<TicTacToeNode*>::iterator map_iter_iter;

	//UCT��RL
	for (map_iter = m_mapTTT.begin(); map_iter != m_mapTTT.end(); map_iter++) {
		for (map_iter_iter = map_iter->second->begin(); map_iter_iter != map_iter->second->end(); map_iter_iter++) {
			delete *map_iter_iter;
		}
		map_iter->second->clear();
		delete map_iter->second;
	}
	m_mapTTT.clear();
}

void MyAI::PlayTicTacToe::Clear()
{
	std::deque<MyAI::TicTacToeNode*>::iterator iter;

	for (iter = m_dequeTTTNodeSpace.begin(); iter < m_dequeTTTNodeSpace.end(); iter++) {
		delete *iter;
	}
	m_dequeTTTNodeSpace.clear();

	if (m_pTTT)
		delete m_pTTT;
	m_pTTT = NULL;

	if (m_hMinimaxThread)
		CloseHandle(m_hMinimaxThread);
	m_hMinimaxThread = NULL;
	m_bResult = false;
}

void MyAI::PlayTicTacToe::Update(MyObjects::TicTacToe& ttt)
{
	if (*m_pTTT == ttt)
		return;

	Clear();
	m_pTTT = new MyObjects::TicTacToe(ttt);
}

//UCT��������
MyAI::TicTacToeNode* MyAI::PlayTicTacToe::UCT(MyObjects::TicTacToe* pRootTTT, int itermax)
{
	MyObjects::TicTacToe* pTTT;
	
	std::unordered_map<int, std::deque<TicTacToeNode*>*>::iterator hash_iter;
	std::deque<MyAI::TicTacToeNode*>::iterator child_iter;

	std::deque<MyObjects::TicTacToeStone*>* pAllMoves;
	std::deque<MyObjects::TicTacToeStone*>::iterator stone_iter;

	MyAI::TicTacToeNode *pNewTTTNode, *pTTTNode;
	MyObjects::TicTacToeStone stone;
	int node;
	bool isSelectFinish;
	int result;
	bool isFirst = true;
	bool isGameEnd;

	TicTacToeNode* pRootNode;

	std::deque<MyAI::TicTacToeNode*>* pDeqBackup;//�������ڵ���ʹ켣�����ڸ��½ڵ���Ϣ
	std::deque<MyAI::TicTacToeNode*>::iterator backup_iter;

	pDeqBackup = new std::deque<MyAI::TicTacToeNode*>();
	srand((unsigned)time(NULL)); //�������������
	for (int i = 0; i < itermax; i++) {

		isGameEnd = false; //���δ����

		pTTT = new MyObjects::TicTacToe(*pRootTTT); //����

		//SELECTION
		isSelectFinish = false;
		while (!isSelectFinish && !isGameEnd) {

			isSelectFinish = true;

			//��ֽڵ㻯����
			node = MyObjects::m_objZobristHash.GenerateHashValue(pTTT->GetTTT(), pTTT->GetWidth(), pTTT->GetHeight(), pTTT->GetDepth());
			pAllMoves = pTTT->GetAllPossibleMoves();
			pNewTTTNode = new MyAI::TicTacToeNode(pTTT->GetLastRow(), pTTT->GetLastCol(), pTTT->GetLastCode(), 
				pTTT->GetDepth(), node, pAllMoves, pTTT->GetPlayer(), &this->m_mapTTT);
			if (!pNewTTTNode->AddToHashmap(&pTTTNode)) {
				delete pNewTTTNode;
			}
			if (i == 0 && isFirst) {
				pRootNode = pTTTNode; //����root node������ʹ��
				isFirst = false;
			}

			pDeqBackup->push_front(pTTTNode); //�����켣
			stone = pTTTNode->UCTSelectChild();
			if (stone.row != -1 && stone.col != -1) {
				isSelectFinish = false;
				pTTT->Play(stone.row, stone.col);
				pTTT->ChgPlayer();

				//�ж�����Ƿ����
				if ((result = pTTT->IsTerminalState()) != MyObjects::TicTacToe::NONTERMINAL) {//��ֽ���
					isGameEnd = true;

					//��ֽڵ㻯����
					node = MyObjects::m_objZobristHash.GenerateHashValue(pTTT->GetTTT(), pTTT->GetWidth(), pTTT->GetHeight(), pTTT->GetDepth());
					pAllMoves = pTTT->GetAllPossibleMoves();
					pNewTTTNode = new MyAI::TicTacToeNode(pTTT->GetLastRow(), pTTT->GetLastCol(), pTTT->GetLastCode(), 
						pTTT->GetDepth(), node, pAllMoves, pTTT->GetPlayer(), &this->m_mapTTT);
					if (!pNewTTTNode->AddToHashmap(&pTTTNode)) {
						delete pNewTTTNode;
					}
					pDeqBackup->push_front(pTTTNode); //�����켣
				}
			}
		}

		//EXPAND
		pAllMoves = pTTT->GetAllPossibleMoves();
		int index;
		if (pAllMoves->size() != 0 && !isGameEnd) {//������չ�������չһ��
			index = rand() % pAllMoves->size();
			stone = *(pAllMoves->at(index));

			pTTT->Play(stone.row, stone.col);
			pTTT->ChgPlayer();

			//�ͷ�pAllMoves�ռ�
			for (stone_iter = pAllMoves->begin(); stone_iter < pAllMoves->end(); stone_iter++)
				delete *stone_iter;
			pAllMoves->clear();
			delete pAllMoves;

			//��ֽڵ㻯����
			node = MyObjects::m_objZobristHash.GenerateHashValue(pTTT->GetTTT(), pTTT->GetWidth(), pTTT->GetHeight(), pTTT->GetDepth());
			pAllMoves = pTTT->GetAllPossibleMoves();
			pNewTTTNode = new MyAI::TicTacToeNode(pTTT->GetLastRow(), pTTT->GetLastCol(), pTTT->GetLastCode(), 
				pTTT->GetDepth(), node, pAllMoves, pTTT->GetPlayer(), &this->m_mapTTT);
			if (!pNewTTTNode->AddToHashmap(&pTTTNode)) {
				delete pNewTTTNode;
			}
			pAllMoves = NULL;
			pDeqBackup->push_front(pTTTNode); //�����켣
		}
		//�ͷ�pAllMoves�ռ�
		if (pAllMoves) {
			for (stone_iter = pAllMoves->begin(); stone_iter < pAllMoves->end(); stone_iter++)
				delete *stone_iter;
			pAllMoves->clear();
			delete pAllMoves;
		}

		//ROLLOUT
		while ((result = pTTT->IsTerminalState()) == MyObjects::TicTacToe::NONTERMINAL) {
			pAllMoves = pTTT->GetAllPossibleMoves();
			index = rand() % pAllMoves->size();
			stone = *(pAllMoves->at(index));
			pTTT->Play(stone.row, stone.col); //�����һ��
			pTTT->ChgPlayer();

			//�ͷ�pAllMoves�ռ�
			for (stone_iter = pAllMoves->begin(); stone_iter < pAllMoves->end(); stone_iter++)
				delete *stone_iter;
			pAllMoves->clear();
			delete pAllMoves;
		}

		//BACKPROPAGATION
		for (backup_iter = pDeqBackup->begin(); backup_iter < pDeqBackup->end(); backup_iter++) {
			pTTTNode = *backup_iter;
			node = pTTTNode->self;
			hash_iter = m_mapTTT.find(node);
			if (hash_iter != m_mapTTT.end()) {//�ҵ�node
				for (child_iter = hash_iter->second->begin(); child_iter < hash_iter->second->end(); child_iter++) {
					if ((*child_iter)->stone.row == pTTTNode->stone.row &&
						(*child_iter)->stone.col == pTTTNode->stone.col &&
						(*child_iter)->depth == pTTTNode->depth) {//��HASH�����ҵ��ýڵ�
							if (!pTTTNode->player) {
								if (result == MyObjects::TicTacToe::XWIN)
									pTTTNode->UCTUpdate(1.0f);
								else if (result == MyObjects::TicTacToe::OWIN)
									pTTTNode->UCTUpdate(0.0f);
								else
									pTTTNode->UCTUpdate(0.5f);
							}
							else {
								if (result == MyObjects::TicTacToe::XWIN)
									pTTTNode->UCTUpdate(0.0f);
								else if (result == MyObjects::TicTacToe::OWIN)
									pTTTNode->UCTUpdate(1.0f);
								else
									pTTTNode->UCTUpdate(0.5f);
							}
							break;
					}
				}
			}
		}

		pDeqBackup->clear();
		delete pTTT;
	}

	//ΪpRootTTT�ҵ����ʴ������Ľڵ�
	pTTTNode = pRootNode->UCTGetMaxChild();

	pDeqBackup->clear();
	
	delete pDeqBackup;

	return pTTTNode;
}