/*
	Programmed by Xiaoqin Du, 383979583@qq.com
	School of Math and Computer Science, 
	Wuhan Textile University
*/

#include "stdafx.h"

#include "PlayTicTacToe.h"

MyAI::TicTacToeNode MyAI::PlayTicTacToe::m_TTTNodeResult;

//minimax��alpha-beta�㷨ʹ��
MyAI::TicTacToeNode::TicTacToeNode()
{
	stone.row = -1;
	stone.col = -1;
	stone.magic_code = -1;
	value = 0;

	depth = 0; //root node
	self = 0;
	depth = 0; //root node
	self = 0;
	rl_value = 0.5f;
	alpha = 0.5f;

	player = true;

	p_child_stones = NULL;
	p_unchild_stones = NULL;
	m_pMapTTT = NULL;
}

MyAI::TicTacToeNode::TicTacToeNode(int row, int col, int code, int depth, int self, std::deque<MyObjects::TicTacToeStone*>* pUntriedChild, bool player, std::unordered_map<int, std::deque<TicTacToeNode*>*>* pMapTTT)
{
	stone.row = row;
	stone.col = col;
	stone.magic_code = code;
	value = 0;

	this->depth = depth;
	this->self = self;
	rl_value = 0.5f; //��ʼֵ
	alpha = 0.5f; //ѧϰ��

	this->player = player; //��ǰ�ڵ���BLACK��������WHITE��

	p_child_stones = new std::deque<MyObjects::TicTacToeStone*>();
	p_unchild_stones = pUntriedChild;

	m_pMapTTT = pMapTTT;
}

MyAI::TicTacToeNode::~TicTacToeNode()
{
	std::deque<MyObjects::TicTacToeStone*>::iterator stone_iter;

	if (p_child_stones) {
		for (stone_iter = p_child_stones->begin(); stone_iter < p_child_stones->end(); stone_iter++) {
			delete *stone_iter;
		}
		p_child_stones->clear();
		delete p_child_stones;
	}

	if (p_unchild_stones) {
		for (stone_iter = p_unchild_stones->begin(); stone_iter < p_unchild_stones->end(); stone_iter++) {
			delete *stone_iter;
		}
		p_unchild_stones->clear();
		delete p_unchild_stones;
	}
}

//�ѱ��ڵ���뵽HASH MAP��
bool MyAI::TicTacToeNode::AddToHashmap(TicTacToeNode** ppTTTNode, bool isGA)
{
	std::unordered_map<int, std::deque<TicTacToeNode*>*>* pMapTTT;

	std::unordered_map<int, std::deque<TicTacToeNode*>*>::iterator hash_iter;
	std::deque<TicTacToeNode*>::iterator node_iter;
	std::deque<TicTacToeNode*>* pDeqNode;
	bool isFind = false;

	pMapTTT = m_pMapTTT;

	//��HASH���в��ұ��ڵ�
	hash_iter = pMapTTT->find(this->self);
	if ( hash_iter != pMapTTT->end()) {//�ҵ���HASHֵ
		for (node_iter = hash_iter->second->begin(); node_iter < hash_iter->second->end(); node_iter++) {
			bool equFlag;
			if (isGA)
				equFlag = (*node_iter)->depth == this->depth;//�Ŵ��㷨��ʹ�á���ͬ����ָ����������
			else
				equFlag = (*node_iter)->stone.row == stone.row &&//UCT��RL�㷨ʹ�ã������ϸ�
				          (*node_iter)->stone.col == stone.col &&
						  (*node_iter)->depth == this->depth;
			if (equFlag) {//�ҵ��øýڵ�
				isFind = true;
				*ppTTTNode = *node_iter;
				break;
			}
		}
		if (!isFind) {
			hash_iter->second->push_back(this);
			*ppTTTNode = this;
		}
	}
	else {//û���ҵ���HASHֵ
		pDeqNode = new std::deque<TicTacToeNode*>();
		pDeqNode->push_back(this);
		pMapTTT->insert(std::unordered_map<int, std::deque<TicTacToeNode*>*>::value_type(this->self, pDeqNode));
		*ppTTTNode = this;
	}

	return !isFind;
}

//��������δ��ʹ��
void MyAI::TicTacToeNode::AddChildToHashmap(MyObjects::TicTacToeStone* pStone, bool isGA)
{
	std::unordered_map<int, std::deque<TicTacToeNode*>*>* pMapTTT;

	TicTacToeNode* pNewNode; //�½��ĺ��ӽڵ㣬����PlayTicTacToe�е�m_mapTTT�ͷ�
	std::deque<MyObjects::TicTacToeStone*>::iterator stone_iter;
	std::deque<MyObjects::TicTacToeStone*>* pDeqTTTStone; //�½��ĺ��ӽڵ��p_unchild_stones������PlayTicTacToe�е�m_mapTTT�ͷ�
	MyObjects::TicTacToeStone* pTTTStone; //�½����ӽڵ�p_unchild_stones�е����������PlayTicTacToe�е�m_mapTTT�ͷ�
	bool isFind;
	int child;
	std::unordered_map<int, std::deque<TicTacToeNode*>*>::iterator hash_iter;
	std::deque<TicTacToeNode*>* pDeqChild;
	std::deque<TicTacToeNode*>::iterator child_iter;

	pMapTTT = m_pMapTTT;

	pDeqTTTStone = new std::deque<MyObjects::TicTacToeStone*>();

	//p_unchild_stones
	for (stone_iter = p_unchild_stones->begin(); stone_iter < p_unchild_stones->end(); stone_iter++) {
		if ((*stone_iter)->row == pStone->row &&
			(*stone_iter)->col == pStone->col) //�ҵ���������
			continue;
		pTTTStone = new MyObjects::TicTacToeStone();
		pTTTStone->row = (*stone_iter)->row;
		pTTTStone->col = (*stone_iter)->col;
		pTTTStone->magic_code = (*stone_iter)->magic_code;
		pDeqTTTStone->push_back(pTTTStone);
	}

	//�½�һ���ڵ㣬����TicTacToe HASH����
	isFind = false;
	child = MyObjects::m_objZobristHash.GenerateHashValue(this->self, pStone->row, pStone->col, player, this->depth, this->depth + 1);
	pNewNode = new TicTacToeNode(pStone->row, pStone->col, pStone->magic_code, 
		this->depth + 1, this->self, pDeqTTTStone, !player, m_pMapTTT);
	//��HASH���в���child
	hash_iter = pMapTTT->find(child);
	if ( hash_iter != pMapTTT->end()) {//�ҵ���HASHֵ
		for (child_iter = hash_iter->second->begin(); child_iter < hash_iter->second->end(); child_iter++) {
			bool equFlag;
			if (isGA)
				equFlag = (*child_iter)->depth == this->depth + 1;
			else
				equFlag = (*child_iter)->stone.row == pStone->row &&
						  (*child_iter)->stone.col == pStone->col &&
						  (*child_iter)->depth == this->depth + 1;
			if (equFlag) {//�ҵ���child
				isFind = true;
				break;
			}
		}
		if (!isFind)
			hash_iter->second->push_back(pNewNode);
	}
	else {//û���ҵ���HASHֵ
		pDeqChild = new std::deque<TicTacToeNode*>();
		pDeqChild->push_back(pNewNode);
		pMapTTT->insert(std::unordered_map<int, std::deque<TicTacToeNode*>*>::value_type(child, pDeqChild));
	}
				
	if (isFind) {//�Ѿ����ڸ�child�ڵ�
		for (stone_iter = pDeqTTTStone->begin(); stone_iter < pDeqTTTStone->end(); stone_iter++) {
			delete *stone_iter;
		}
		pDeqTTTStone->clear();
		delete pDeqTTTStone;

		delete pNewNode;
	}
}

//RL����:greedy�㷨��ѡȡ���rl_valueֵ�ĺ��ӽڵ�
MyAI::TicTacToeNode* MyAI::TicTacToeNode::RLGetMaxChild()
{
	int child; //���ӽڵ�HASHֵ
	TicTacToeNode* max_node = NULL; //����rl_valueֵ��ߵĺ��ӽڵ�
	float max_rl_value = -1000.0f; //�������rl_value

	std::deque<MyObjects::TicTacToeStone*>::iterator stone_iter; //p_unchild_stones������
	std::unordered_map<int, std::deque<TicTacToeNode*>*>::iterator hash_iter;
	std::deque<TicTacToeNode*>::iterator child_iter; //HASHֵ��ͬ�Ľڵ������

	for (stone_iter = p_unchild_stones->begin(); stone_iter < p_unchild_stones->end(); stone_iter++) {//�������еĺ��ӽڵ�����
		//���ɺ��ӽڵ��HASHֵ
		child = MyObjects::m_objZobristHash.GenerateHashValue(this->self, (*stone_iter)->row, (*stone_iter)->col, player, this->depth, this->depth + 1);
		//��HASH���в���child
		hash_iter = m_pMapTTT->find(child);
		if ( hash_iter != m_pMapTTT->end()) {//�ҵ�child
			for (child_iter = hash_iter->second->begin(); child_iter < hash_iter->second->end(); child_iter++) {
				if ((*child_iter)->stone.row == (*stone_iter)->row &&
					(*child_iter)->stone.col == (*stone_iter)->col &&
					(*child_iter)->depth == this->depth + 1) {//׼ȷ���ҵ�����HASHֵ��ͬchild�е�һ��
						if ((*child_iter)->rl_value > max_rl_value) {//���ʴ�������ʤ�����
							max_rl_value = (*child_iter)->rl_value;
							max_node = *child_iter;
						}
						break;
				}
			}
		}
	}

	return max_node;
}

//RL: TD-Learningֵ����
void MyAI::TicTacToeNode::RLUpdate(TicTacToeNode* pNextNode)
{
	this->rl_value += alpha * (pNextNode->rl_value - this->rl_value);
}

MyAI::PlayTicTacToe::PlayTicTacToe(MyObjects::TicTacToe& ttt)
{
	m_pTTT = new MyObjects::TicTacToe(ttt);
	m_hMinimaxThread = NULL;
	m_bResult = false;
}

MyAI::PlayTicTacToe::~PlayTicTacToe()
{
	Clear();
	ClearHashMap();
}

void MyAI::PlayTicTacToe::ClearHashMap()
{
	std::unordered_map<int, std::deque<TicTacToeNode*>*>::iterator map_iter;
	std::deque<TicTacToeNode*>::iterator map_iter_iter;

	//UCT��RL
	for (map_iter = m_mapTTT.begin(); map_iter != m_mapTTT.end(); map_iter++) {
		for (map_iter_iter = map_iter->second->begin(); map_iter_iter != map_iter->second->end(); map_iter_iter++) {
			delete *map_iter_iter;
		}
		map_iter->second->clear();
		delete map_iter->second;
	}
	m_mapTTT.clear();
}

void MyAI::PlayTicTacToe::Clear()
{
	std::deque<MyAI::TicTacToeNode*>::iterator iter;

	for (iter = m_dequeTTTNodeSpace.begin(); iter < m_dequeTTTNodeSpace.end(); iter++) {
		delete *iter;
	}
	m_dequeTTTNodeSpace.clear();

	if (m_pTTT)
		delete m_pTTT;
	m_pTTT = NULL;

	if (m_hMinimaxThread)
		CloseHandle(m_hMinimaxThread);
	m_hMinimaxThread = NULL;
	m_bResult = false;
}

void MyAI::PlayTicTacToe::Update(MyObjects::TicTacToe& ttt)
{
	if (*m_pTTT == ttt)
		return;

	Clear();
	m_pTTT = new MyObjects::TicTacToe(ttt);
}

//RL TDLearning����
MyAI::TicTacToeNode* MyAI::PlayTicTacToe::TDLearning(MyObjects::TicTacToe* pRootTTT, int itermax)
{
	MyObjects::TicTacToe *pTTT, *pTTTExpand;
	
	std::unordered_map<int, std::deque<TicTacToeNode*>*>::iterator hash_iter;
	std::deque<MyAI::TicTacToeNode*>::iterator child_iter;

	std::deque<MyObjects::TicTacToeStone*>* pAllMoves;
	std::deque<MyObjects::TicTacToeStone*>::iterator stone_iter;

	MyAI::TicTacToeNode *pRootNode, *pNewTTTNode, *pTTTNode, *pTTTNodeBak;
	MyAI::TicTacToeNode *pRLNode;
	MyObjects::TicTacToeStone stone;
	int node;
	int result;
	bool isFirst = true;
	bool isGameEnd;
	float epsilon = 0.01f; //̽����
	bool isExplore; //�Ƿ�̽��
		
	for (int i = 0; i < itermax; i++) {//��ʼTD-Learning��RUN

		isGameEnd = false; //���δ����
		pRLNode = NULL;

		pTTT = new MyObjects::TicTacToe(*pRootTTT); //����

		while (!isGameEnd) {//GAME

			//��ֽڵ㻯����
			node = MyObjects::m_objZobristHash.GenerateHashValue(pTTT->GetTTT(), pTTT->GetWidth(), pTTT->GetHeight(), pTTT->GetDepth());
			pAllMoves = pTTT->GetAllPossibleMoves();
			pNewTTTNode = new MyAI::TicTacToeNode(pTTT->GetLastRow(), pTTT->GetLastCol(), pTTT->GetLastCode(), 
				pTTT->GetDepth(), node, pAllMoves, pTTT->GetPlayer(), &this->m_mapTTT);
			if (!pNewTTTNode->AddToHashmap(&pTTTNode)) {//�ڵ��Ѿ�����
				delete pNewTTTNode;
			}
			if (i == 0 && isFirst) {
				pRootNode = pTTTNode; //����root node������ʹ��
				isFirst = false;
			}

			//�����һ���ӽڵ���뵽HASH MAP�У�
			//��1������HASH MAP�иýڵ���ӽڵ�Ϊ�գ�
			//��2�������������ȫ�����ӽڵ㣬��ռ�ռ�ù���
			pTTTNodeBak = pTTTNode; //����pTTTNode
			pTTTExpand = new MyObjects::TicTacToe(*pTTT); //����
			pAllMoves = pTTTExpand->GetAllPossibleMoves();
			int index;
			if (pAllMoves->size() != 0) {//������չ�������չһ��
				index = rand() % pAllMoves->size();
				stone = *(pAllMoves->at(index));

				pTTTExpand->Play(stone.row, stone.col);
				pTTTExpand->ChgPlayer();

				//�ͷ�pAllMoves�ռ�
				for (stone_iter = pAllMoves->begin(); stone_iter < pAllMoves->end(); stone_iter++)
					delete *stone_iter;
				pAllMoves->clear();
				delete pAllMoves;

				//��ֽڵ㻯����
				node = MyObjects::m_objZobristHash.GenerateHashValue(pTTTExpand->GetTTT(), pTTTExpand->GetWidth(), pTTTExpand->GetHeight(), pTTTExpand->GetDepth());
				pAllMoves = pTTTExpand->GetAllPossibleMoves();
				pNewTTTNode = new MyAI::TicTacToeNode(pTTTExpand->GetLastRow(), pTTTExpand->GetLastCol(), pTTTExpand->GetLastCode(), 
					pTTTExpand->GetDepth(), node, pAllMoves, pTTTExpand->GetPlayer(), &this->m_mapTTT);
				if (!pNewTTTNode->AddToHashmap(&pTTTNode)) {//�ڵ��Ѿ�����
					delete pNewTTTNode;
				}
				pAllMoves = NULL;

				//�ж�����Ƿ����
				if ((result = pTTTExpand->IsTerminalState()) != MyObjects::TicTacToe::NONTERMINAL) {//��ֽ���
					//�޸�����ѧϰ״ֵ̬��ֻ���ʤ��������״ֵ̬��ʼ����0.5��
					if (!pTTTNode->player) {
						if (result == MyObjects::TicTacToe::XWIN)
							pTTTNode->rl_value = 1.0f;
						else if (result == MyObjects::TicTacToe::OWIN)
							pTTTNode->rl_value = 0.0f;
					}
					else {
						if (result == MyObjects::TicTacToe::XWIN)
							pTTTNode->rl_value = 0.0f;
						else if (result == MyObjects::TicTacToe::OWIN)
							pTTTNode->rl_value = 1.0f;
					}
				}
			}
			//�ͷ�pAllMoves�ռ�
			if (pAllMoves) {
				for (stone_iter = pAllMoves->begin(); stone_iter < pAllMoves->end(); stone_iter++)
					delete *stone_iter;
				pAllMoves->clear();
				delete pAllMoves;
			}
			delete pTTTExpand;
			pTTTNode = pTTTNodeBak;//��ԭpTTTNode

			//�Ƿ�̽��
			isExplore = (rand() / (float)RAND_MAX) < epsilon;
			if (isExplore) {//̽��
				pAllMoves = pTTT->GetAllPossibleMoves();
				int index;
				if (pAllMoves->size() != 0) {//������չ�������չһ��
					index = rand() % pAllMoves->size();
					stone = *(pAllMoves->at(index));
				}
				else {
					stone.row = -1; stone.col = -1;
					isGameEnd = true;
				}
				//�ͷ�pAllMoves�ռ�
				if (pAllMoves) {
					for (stone_iter = pAllMoves->begin(); stone_iter < pAllMoves->end(); stone_iter++)
						delete *stone_iter;
					pAllMoves->clear();
					delete pAllMoves;
				}
			}
			else {//ѧϰ
				TicTacToeNode* pMaxNode = pTTTNode->RLGetMaxChild();
				stone = pMaxNode->stone;
			}

			//ѧϰ������
			if (stone.row != -1 && stone.col != -1) {
				pTTT->Play(stone.row, stone.col);
				pTTT->ChgPlayer();

				//��ֽڵ㻯����
				node = MyObjects::m_objZobristHash.GenerateHashValue(pTTT->GetTTT(), pTTT->GetWidth(), pTTT->GetHeight(), pTTT->GetDepth());
				pAllMoves = pTTT->GetAllPossibleMoves();
				pNewTTTNode = new MyAI::TicTacToeNode(pTTT->GetLastRow(), pTTT->GetLastCol(), pTTT->GetLastCode(), 
					pTTT->GetDepth(), node, pAllMoves, pTTT->GetPlayer(), &this->m_mapTTT);
				if (!pNewTTTNode->AddToHashmap(&pTTTNode)) {//�ڵ��Ѿ�����
					delete pNewTTTNode;
				}

				//�ж�����Ƿ����
				if ((result = pTTT->IsTerminalState()) != MyObjects::TicTacToe::NONTERMINAL) {//��ֽ���
					isGameEnd = true;
					//�޸�����ѧϰ״ֵ̬��ֻ���ʤ��������״ֵ̬��ʼ����0.5��
					if (!pTTTNode->player) {
						if (result == MyObjects::TicTacToe::XWIN)
							pTTTNode->rl_value = 1.0f;
						else if (result == MyObjects::TicTacToe::OWIN)
							pTTTNode->rl_value = 0.0f;
					}
					else {
						if (result == MyObjects::TicTacToe::XWIN)
							pTTTNode->rl_value = 0.0f;
						else if (result == MyObjects::TicTacToe::OWIN)
							pTTTNode->rl_value = 1.0f;
					}
					if (pRLNode)
						pRLNode->RLUpdate(pTTTNode);
				}
				else {
					if (pRLNode && !isExplore) {
						pRLNode->RLUpdate(pTTTNode);
					}
					pRLNode = pTTTNode; //����TD-Learning
				}
			}

			//��һ���������
			if (!isGameEnd) {
				pAllMoves = pTTT->GetAllPossibleMoves();
				int index;
				if (pAllMoves->size() != 0) {//������չ�������չһ��
					index = rand() % pAllMoves->size();
					stone = *(pAllMoves->at(index));
				}
				else {
					stone.row = -1; stone.col = -1;
					isGameEnd = true;
				}
				//�ͷ�pAllMoves�ռ�
				if (pAllMoves) {
					for (stone_iter = pAllMoves->begin(); stone_iter < pAllMoves->end(); stone_iter++)
						delete *stone_iter;
					pAllMoves->clear();
					delete pAllMoves;
				}
				if (stone.row != -1 && stone.col != -1) {
					pTTT->Play(stone.row, stone.col);
					pTTT->ChgPlayer();

					//��ֽڵ㻯����
					node = MyObjects::m_objZobristHash.GenerateHashValue(pTTT->GetTTT(), pTTT->GetWidth(), pTTT->GetHeight(), pTTT->GetDepth());
					pAllMoves = pTTT->GetAllPossibleMoves();
					pNewTTTNode = new MyAI::TicTacToeNode(pTTT->GetLastRow(), pTTT->GetLastCol(), pTTT->GetLastCode(), 
						pTTT->GetDepth(), node, pAllMoves, pTTT->GetPlayer(), &this->m_mapTTT);
					if (!pNewTTTNode->AddToHashmap(&pTTTNode)) {//�ڵ��Ѿ�����
						delete pNewTTTNode;
					}

					//�ж�����Ƿ����
					if ((result = pTTT->IsTerminalState()) != MyObjects::TicTacToe::NONTERMINAL) {//��ֽ���
						isGameEnd = true;
						//�޸�����ѧϰ״ֵ̬��ֻ���ʤ��������״ֵ̬��ʼ����0.5��
						if (pTTTNode->player) {
							if (result == MyObjects::TicTacToe::XWIN)
								pTTTNode->rl_value = 1.0f;
							else if (result == MyObjects::TicTacToe::OWIN)
								pTTTNode->rl_value = 0.0f;
						}
						else {
							if (result == MyObjects::TicTacToe::XWIN)
								pTTTNode->rl_value = 0.0f;
							else if (result == MyObjects::TicTacToe::OWIN)
								pTTTNode->rl_value = 1.0f;
						}
						if (pRLNode)
							pRLNode->RLUpdate(pTTTNode);
					}
				}
			}
		}

		delete pTTT;
	}

	//ΪpRootTTT�ҵ�״ֵ̬��õĽڵ�
	pTTTNode = pRootNode->RLGetMaxChild();

	return pTTTNode;
}