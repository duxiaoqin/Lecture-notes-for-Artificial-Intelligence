'''
Created on sun 2020/10/4 21:

@author: zhengfengbao, 郑逢宝, 计算机11801, 1804240131

Functions:
    (1)FC-3 Algorithm for one solution;
'''

from graphics import *
from board import *
from boarddraw import *
import copy
import time


class viInfo:
    def __init__(self, v):
        self.value = v
        self.flag = Board.UNMARK
        self.level = 0


def DomainWipedOut(Xi, Vi):
    for vi in Vi:
        if vi.flag == Board.UNMARK:
            return False
    return True


def RestoreDomainAtLevel(Vars, level):
    for Xi, Vi in Vars:
        for vi in Vi:
            if vi.flag == Board.MARK and vi.level == level:
                vi.flag = Board.UNMARK


def ForwardChecking(Vars, level, Xi, vi):
    for Xj, Vj in Vars:
        for vj in Vj:
            if (Xi == Xj or vi.value == vj.value or abs(Xi-Xj) == abs(vi.value-vj.value)):
                if vj.flag == Board.UNMARK:
                    vj.flag = Board.MARK
                    vj.level = level
        if DomainWipedOut(Xj, Vj):
            return False

    return True


def BacktrackingWithForwardChecking(Vars, level, Solution):
    Xi, Vi = Vars[0]
    for vi in Vi:
        if vi.flag == Board.UNMARK:
            Solution.append((Xi, vi))
            if len(Vars) == 1:
                return True
            else:
                Vars_C = copy.deepcopy(Vars)
                Vars_C.pop(0)
                if ForwardChecking(Vars_C, level, Xi, vi) and \
                        BacktrackingWithForwardChecking(Vars_C, level+1, Solution):
                    return True
                else:
                    Solution.pop()
                    RestoreDomainAtLevel(Vars_C, level)
    return False


def main():
    win = GraphWin('Backtracking with FC-3 for Queen', 600, 600, autoflush=False)
    n = 8
    board = Board(n)

    Vars = []
    Vi = [viInfo(i) for i in range(n)]
    for row in range(board.height):
        Vars.append((row, copy.deepcopy(Vi)))
    text = Text(Point(board.width/2+1, 0.5), 'Searching...')
    text.setTextColor('red')
    text.draw(win)

    boarddraw = BoardDraw(win, board, 'Queen8-1.png', 'Queen8-2.png')
    boarddraw.draw(board)
    Solution = []
    BacktrackingWithForwardChecking(Vars, 1, Solution)

    for Xi, vi in Solution:
        board[Xi, vi.value] = Board.OCCUPIED

    while win.checkKey() != 'Escape':
        text.setText('Finished!')
        boarddraw.draw(board)

    win.close()


if __name__ == "__main__":
    main()
