# -*- coding: utf-8 -*-
"""
Created on Tue Nov 27 15:30:51 2018

@author: duxiaoqin
Functions:
    (1) Calculate max{f(x)} & x;
    (2) The result are 'max{f(x)} =  15.139931582414201  x =  6.7524999999999995'
"""

from math import *
import sys

num = 10000

X = [i+j/num for i in range(11) for j in range(num)]

max_value = -sys.maxsize
max_x = 0

for x in X:
    y = x + 2*sin(2*x) + 3*sin(3*x) + 4*sin(4*x)
    if max_value < y:
        max_value = y
        max_x = x
        
print('max{f(x)} = ', max_value, ' x = ', max_x)