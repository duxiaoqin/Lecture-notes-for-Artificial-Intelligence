需求：python 3.6
执行：
python fast-downward.py gripper2_domain.pddl gripper2_problem.pddl --heuristic "h=ff()" --search "astar(lmcut())"