# simple1.py
# Simple Graphics Program
from graphics import *

win = GraphWin()
p1 = Point(50, 60)
print(p1.getX())
print(p1.getY())
p1.draw(win)
p2 = Point(140, 100)
p2.draw(win)

input("Please enter any key to exit")
win.close()