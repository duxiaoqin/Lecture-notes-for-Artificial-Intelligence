# simple2.py
# Simple Graphics Program
from graphics import *

win = GraphWin()
center = Point(100, 100)
circle = Circle(center, 20)
circle.setOutline('green')
circle.setFill('blue')
circle.draw(win)

label = Text(center, "Circle")
label.draw(win)

rect = Rectangle(Point(30, 50), Point(170, 150))
rect.setOutline('pink')
rect.draw(win)

line = Line(Point(30, 50), Point(170, 150))
line.setOutline('red')
line.draw(win)

oval = Oval(Point(30, 50), Point(170, 150))
oval.draw(win)


input("Please enter any key to exit")
win.close()