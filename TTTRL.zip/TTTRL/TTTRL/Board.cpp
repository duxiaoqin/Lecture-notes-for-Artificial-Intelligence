/*
	Programmed by Xiaoqin Du, 383979583@qq.com
	School of Math and Computer Science, 
	Wuhan Textile University
*/

#include "stdafx.h"

#include "Board.h"

MyObjects::Board::Board()
{
}

MyObjects::Board::~Board()
{
}