from graphics import *

def main():
    win = GraphWin('Histogram', 640, 480)
    
    infile = open('histogram.txt', 'r')
    data = infile.readlines()
    data = [float(item) for item in data]
    maxx = len(data)
    maxy = max(data)
    win.setCoords(0.0, 0.0, maxx, maxy)
    bar_width = 0.6
    for index in range(len(data)):
        bar = Rectangle(Point(index*1+0.2,0), Point(index*1.0+0.2+bar_width, data[index]))
        bar.setFill(color_rgb(130, 0, 130))
        bar.setWidth(2)
        bar.draw(win)
    
    while win.getKey() != 'Escape':
        pass
    win.close()
    
if __name__ == '__main__':
    main()