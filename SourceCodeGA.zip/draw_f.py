import numpy as np
import matplotlib.pyplot as plt
x = np.arange(-10,10,0.1)
y=x+2*np.sin(2*x)+3*np.sin(3*x)+4*np.sin(4*x)
plt.plot(x,y)
plt.show()