/*
	Programmed by Xiaoqin Du, 383979583@qq.com
	School of Math and Computer Science, 
	Wuhan Textile University
*/

#pragma once

#include <fstream>
#include <deque>

namespace MyObjects {
	
	struct TicTacToeStone {//TicTacToe����λ����Ϣ
		int row;
		int col;
		short magic_code;

		friend std::ifstream& operator>>(std::ifstream& in, TicTacToeStone& stone);
		friend std::ofstream& operator<<(std::ofstream& out, TicTacToeStone& stone);
	};

	std::ifstream& operator>>(std::ifstream& in, std::deque<MyObjects::TicTacToeStone*>*& pDeqStone);
	std::ofstream& operator<<(std::ofstream& out, std::deque<MyObjects::TicTacToeStone*>* pDeqStone);
}