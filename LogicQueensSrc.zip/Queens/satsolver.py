# -*- coding: utf-8 -*-
"""
Created on Tue Aug 18 20:10:45 2020

@author: duxiaoqin
Prerequisite: MiniSAT for Windows/Ubuntu
Functions:
    (1) N Queens for MiniSAT;
"""

import os
from myarray2d import Array2D

size = 8
line_counter = 0
filein = 'queens{}.in'.format(size)
fileout = 'queens{}.out'.format(size)

template = Array2D(size, size)
for row in range(size):
    for col in range(size):
        template[row, col] = row * size + col + 1

constraints = ''

# row constraints
for row in range(size):
    for col in range(size):
        constraints += str(template[row, col]) + ' '
    constraints += '0\n'
    line_counter += 1
    for col1 in range(size):
        for col2 in range(col1 + 1, size):
            constraints += '-' + str(template[row, col1]) + ' -' + str(template[row, col2]) + ' 0\n'
            line_counter += 1

# column constraints
for col in range(size):
    for row in range(size):
        constraints += str(template[row, col]) + ' '
    constraints += '0\n'
    line_counter += 1
    for row1 in range(size):
        for row2 in range(row1 + 1, size):
            constraints += '-' + str(template[row1, col]) + ' -' + str(template[row2, col]) + ' 0\n'
            line_counter += 1

# main diagonal constraints
# upper triangle
for col in range(size - 2, -1, -1):
    for row1 in range(size - col):
        for row2 in range(row1 + 1, size - col):
            constraints += '-' + str(template[row1, col + row1]) + ' -' + str(template[row2, col + row2]) + ' 0\n'
            line_counter += 1
# lower triangle
for row in range(size - 2, 0, -1):
    for col1 in range(size - row):
        for col2 in range(col1 + 1, size - row):
            constraints += '-' + str(template[row + col1, col1]) + ' -' + str(template[row + col2, col2]) + ' 0\n'
            line_counter += 1

# secondary diagonal constraints
# lower triangle
for col in range(size - 2, -1, -1):
    for row1 in range(size - 1, col - 1, -1):
        for row2 in range(row1 - 1, col - 1, -1):
            constraints += '-' + str(template[row1, col + size - 1 - row1]) + ' -' + str(template[row2, col + size -1 - row2]) + ' 0\n'
            line_counter += 1
# upper triangle
for row in range(1, size - 1):
    for col1 in range(row + 1):
        for col2 in range(col1 + 1, row + 1):
            constraints += '-' + str(template[row - col1, col1]) + ' -' + str(template[row - col2, col2]) + ' 0\n'
            line_counter += 1

with open(filein, 'w') as f:
    f.write('c {}-queens problem (sat)\n'.format(size))
    f.write('p cnf {} {}\n'.format(size * size, line_counter))
    f.write(constraints)

exe = 'Minisat.exe ' + filein + ' ' + fileout + ' > ' + fileout + '.log'
allresults = ''
solution_counter = 0
while True:    
    os.system(exe)

    fout = open(fileout)
    results = fout.readlines()
    fout.close()
    if results[0] == 'UNSAT\n':
        break
    solution_counter += 1
    print('Solving ... {} Solutions found!'.format(solution_counter))
    allresults += results[1]
    lvariables = results[1].split()
    newlvs = ''
    for lv in lvariables:
        newlvs += str(-int(lv)) + ' '
    newlvs += '\n'
    fin = open(filein)
    inlines = fin.readlines()
    fin.close()
    line2nd = inlines[1].split()
    line2nd[3] = str(int(line2nd[3])+1)
    newinline = ''
    for inline in line2nd:
        newinline += inline + ' '
    newinline += '\n'
    fin = open(filein, 'w')
    fin.write(inlines[0])
    fin.write(newinline)
    fin.writelines(inlines[2:])
    fin.write(newlvs)
    fin.close()
if solution_counter == 0:
    print('No solution found!')
with open(fileout, 'w') as f:
    f.write(str(solution_counter) + '\n')
    f.writelines(allresults)