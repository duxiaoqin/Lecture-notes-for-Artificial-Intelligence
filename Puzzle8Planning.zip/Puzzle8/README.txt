（1）需要Python3.6以上；
（2）编译链接downward；
（3）运行“python fast-downward.py puzzle8_domain.pddl puzzle8_problem.pddl --heuristic "h=ff()" --search "astar(lmcut())"”，Puzzle8实例；
     运行“python fast-downward.py puzzle8_domain.pddl puzzle8_problem.pddl --heuristic "h=ff()" --search "astar(lmcut())"”，Puzzle15实例；

注：此处的downward为复制过来的简易版本（有些文件与目录没有被复制。如果出现不能运行某些PDDL文件的情况，可以考虑此因素）；
downward的完整工程（已编译链接）位于目录：E:\msys64\home\psdz\downward

PDDL文件来源：https://ai.dmi.unibas.ch/archive/hs2016/planning-and-optimization/index.html