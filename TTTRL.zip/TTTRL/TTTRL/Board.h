/*
	Programmed by Xiaoqin Du, 383979583@qq.com
	School of Math and Computer Science, 
	Wuhan Textile University
*/

#pragma once

namespace MyObjects {
	class Board {
	public:
		Board();
		~Board();

		static const short BLACKFLAG = 1;
		static const short WHITEFLAG = -1;
		static const short SELFLAG = -2;
		static const short EMPTYFLAG = 0;
	};
}