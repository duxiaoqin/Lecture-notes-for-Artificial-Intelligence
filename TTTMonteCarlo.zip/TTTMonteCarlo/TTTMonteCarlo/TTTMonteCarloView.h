
// TTTMonteCarloView.h : interface of the CTTTMonteCarloView class
//

#pragma once

#include "TicTacToe.h"
#include "TicTacToeDraw.h"
#include "TicTacToeInput.h"
#include "PlayTicTacToe.h"

//���庯��ģ�壬���ڳ�Ա�����̻߳�
template <typename TYPE, void (MyAI::PlayTicTacToe::*DoUCT)()>
DWORD WINAPI ThreadComputerTurn_UCT(LPVOID lpParameter)
{
	TYPE* pView = (TYPE*)lpParameter;
	pView->GetTTTPlay()->DoUCT();
	return 0;
}

class CTTTMonteCarloView : public CView
{
protected: // create from serialization only
	CTTTMonteCarloView();
	DECLARE_DYNCREATE(CTTTMonteCarloView)

// Attributes
public:
	CTTTMonteCarloDoc* GetDocument() const;

// Operations
public:
	enum WHO_FIRST {COMPUTER_FIRST, HUMAN_FIRST};
	MyObjects::TicTacToe* GetTTT() {return m_pTTT;}
	MyAI::PlayTicTacToe* GetTTTPlay() {return m_pTTTPlay;}
	void ComputerTurn() {
		if (m_hTTTPlayThread) {
			CloseHandle(m_hTTTPlayThread);
			m_hTTTPlayThread = NULL;
		}
		m_hTTTPlayThread = CreateThread(NULL, 0, ThreadComputerTurn_UCT<CTTTMonteCarloView, &MyAI::PlayTicTacToe::DoUCT>, this, 0, NULL);
	}
	WHO_FIRST GetWhoFirst() {return m_enumWhoFirst;}
	void RegenerateTTT();

private:
	MyObjects::TicTacToe* m_pTTT;
	MyGDI::TicTacToeDraw* m_pTTTDraw;
	MyInput::TicTacToeInput* m_pTTTInput;
	MyAI::PlayTicTacToe* m_pTTTPlay;
	HANDLE m_hTTTPlayThread;

	WHO_FIRST m_enumWhoFirst;

private:
	void Play();

	void ClearTTT();

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CTTTMonteCarloView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TTTMonteCarloView.cpp
inline CTTTMonteCarloDoc* CTTTMonteCarloView::GetDocument() const
   { return reinterpret_cast<CTTTMonteCarloDoc*>(m_pDocument); }
#endif

